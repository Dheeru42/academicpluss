<?php
$servername="localhost";
$username="dheeraj";
$password="Aligarh9@";
$database="acad_p";
$conn=mysqli_connect($servername,$username,$password,$database);
if (!$conn) 
{
    die("Error".mysqli_connect_error());    
}
?>