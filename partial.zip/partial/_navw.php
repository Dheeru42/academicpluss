<?php 
if(isset($_SESSION['loggedin']) && $_SESSION['loggedin']==true) 
{
  $loggedin=true;
}
else 
{
  $loggedin=false;
}
echo '
<nav class="navbar navbar-expand-lg bg-body-tertiary">
<div class="class fluid">
            <img src="pen.png" height="60px">
            </div>
  <div class="container-fluid">
    <a class="navbar-brand" href="welcome.php"><b>academicpluss</b></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="welcome.php">Home</a>
        </li>';


echo '</ul>
<form class="d-flex" role="search">
<a href="searchnav.php" class="btn btn-outline-info"><b>Search</b></a>
      </form>
    </div>
  </div>';



  
if(!$loggedin)
{ 
      echo  '<ul class="navbar-nav me-auto mb-2 mb-lg-0">
      <li class="nav-item">
          <a class="nav-link" href="signup.php">SignUp</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="index.php">Login</a>
        </li>
        </ul>';
}

if($loggedin)
{
echo '<ul class="navbar-nav me-auto mb-2 mb-lg-0">
<li class="nav-item">
          <a class="nav-link" href="logout.php">LogOut</a>
        </li>
        </ul>';
}

echo '</nav>';
?>

