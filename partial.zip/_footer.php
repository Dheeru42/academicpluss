

<?php
echo '<footer class="py-3 my-4">
<div class = "cen">
<img src="pen.png" alt="" srcset="" widhth="100px" height="100px">
</div>
<br>
<ul class="nav justify-content-center border-bottom pb-3 mb-3">
  <li class="nav-item"><a href="homep.php" class="nav-link px-2 text-muted"><b>Home</b></a></li>
  <li class="nav-item"><a href="aboutp.php" class="nav-link px-2 text-muted"><b>About Us</b></a></li>
  <li class="nav-item"><a href="searchnav.php" class="nav-link px-2 text-muted"><b>Search</b></a></li>
  <li class="nav-item"><a href="Contact Us.php" class="nav-link px-2 text-muted"><b>Contact Us</b></a></li>
  <li class="nav-item"><a href="faq.php" class="nav-link px-2 text-muted"><b>FAQ</a></b></li>
</ul>
<h6 class="text-center text-muted"><u><b>Copyright © 2023-24 academicpluss - All rights reserved.</b></u></h6>
</footer>';

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    .cen {
      text-align: center;
    }
        
  </style>
</head>

<body>

</body>

</html>