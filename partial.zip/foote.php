
<?php
echo '<footer class="py-3 my-4">
<div class = "cen">
<img src="pen.png" alt="" srcset="" widhth="100px" height="100px">
</div>
<br>
<ul class="nav justify-content-center border-bottom pb-3 mb-3">
  <li class="nav-item"><a href="expertwel.php" class="nav-link px-2 text-muted"><b>Home</b></a></li>
</ul>
<h5 class="text-center text-muted"><b><u>Copyright © 2023-24 academicpluss - All rights reserved.</u></b></h5>
</footer>';

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    .cen {
      text-align: center;
    }
  </style>
</head>

<body>

</body>

</html>